// Put your Supabase values here (Project Settings -> API). The anon key is safe to be public.
window.GF_CONFIG = { SUPABASE_URL: "", SUPABASE_ANON_KEY: "" };
